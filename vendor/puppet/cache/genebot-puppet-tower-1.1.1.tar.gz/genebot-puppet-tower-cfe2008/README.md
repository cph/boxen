# Tower Puppet Module for Boxen [![Build Status](https://travis-ci.org/boxen/puppet-tower.png?branch=master)](https://travis-ci.org/boxen/puppet-tower)

Install [Tower](http://www.git-tower.com), an easy way to share files
and folders on Mac OS X.

## Usage

```puppet
include tower
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
