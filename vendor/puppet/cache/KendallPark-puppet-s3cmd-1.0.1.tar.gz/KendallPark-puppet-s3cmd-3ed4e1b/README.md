# s3cmd

Installs and configures s3cmd

