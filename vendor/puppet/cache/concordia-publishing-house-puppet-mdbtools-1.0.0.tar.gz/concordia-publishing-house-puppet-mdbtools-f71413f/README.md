# MDBTools Puppet Module for Boxen

## Usage

```puppet
include mdbtools
```

## Required Puppet Modules

 - homebrew

## Developing / Contributing

 - Make it better!
 - Run `script/cibuild`
 - Pull request!
