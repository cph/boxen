require 'spec_helper'

describe 'mdbtools' do
  it do
    should contain_package('mdbtools')
  end
end
