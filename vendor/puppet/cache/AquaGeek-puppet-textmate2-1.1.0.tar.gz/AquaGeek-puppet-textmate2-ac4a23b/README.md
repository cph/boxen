# TextMate Puppet Module for Boxen

## Usage

```puppet
include textmate
```

## Required Puppet Modules

* boxen
