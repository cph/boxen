require 'spec_helper'

describe 'KeyCastr' do
  it do
    should contain_package('KeyCastr').with({
      :provider => 'compressed_app'
    })
  end
end
