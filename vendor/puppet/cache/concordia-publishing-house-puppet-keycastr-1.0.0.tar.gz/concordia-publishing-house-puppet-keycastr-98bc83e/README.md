# Postgres.app Puppet Module for Boxen

Install [KeyCastr.app](https://github.com/keycastr/keycastr) via Boxen.

## Usage

```puppet
include keycastr
```

## Required Puppet Modules

* `boxen`
